import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-song-display',
  templateUrl: './song-display.component.html',
  styleUrls: ['./song-display.component.scss']
})
export class SongDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
