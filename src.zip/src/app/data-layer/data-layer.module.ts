import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {ServiceService} from './service.service';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HttpClient,

  ],
  exports: [ServiceService],
})
export class DataLayerModule { }
